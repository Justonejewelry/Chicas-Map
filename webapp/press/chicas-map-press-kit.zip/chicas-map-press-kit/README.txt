Chicas Map press kit
https://www.chicasmap.com/press/

Chicas Map is a free, veteran-built map of garage, yard, and estate sales
in San Antonio and nearby towns. The mascot is Chica.

You are welcome to use these files to talk about Chicas Map. Keep the cape
magenta (#C513AF). Do not stretch or recolor the logo, and do not suggest
Chica endorses a product she does not. For a different crop, or for press
questions, use the Contact page: https://www.chicasmap.com/bulletin/

Brand colors (from the site CSS):
  Cape / brand pink   #C513AF   --chica-pine
  Cape mid            #E23BC4   --chica-pine-mid
  Cape deep           #9A0E88   --chica-pine-deep
  Dark background     #121212   --chica-bg
  Light background    #F4F0EA
  Ink (dark theme)    #F4F4F4
  Ink (light theme)   #1A1614

Type: Syne for headings, Inter for body text.
